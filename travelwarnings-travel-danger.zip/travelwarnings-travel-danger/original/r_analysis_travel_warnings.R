## Top countries for travel warnings --------------------------------

# Load data 
countrycodes <- read.csv("https://query.data.world/s/do8eacem7jtjsclgr0ifzex20",header=T, stringsAsFactors = F)
library(rio)
regions <- import("https://query.data.world/s/2q7wm98dkyuoxxu6brmq3yqll",header=T)
regionsonly <- regions[, c("name", "region")]
SDwarnings <- read.csv("https://query.data.world/s/4jn8nbk5yk1qyq9e9ow69uy9l",header=T, stringsAsFactors = F)

# Weed out natural disasters
disasterwords <- c("hurricane", "tropical storm", "earthquake", "cyclone", "monsoon", "typhoon")
SDwarnings$description <- tolower(SDwarnings$description)
discards <- vector()
for (i in 1:length(disasterwords)) {
  matchinds <- grep(disasterwords[i], SDwarnings$description)
  discards <- c(discards, matchinds)
}
discards <- unique(discards)
SDwarnings <- SDwarnings[-discards,]

# Extract # of warnings for each country
countries <- countrycodes$Description
SDwarnings_list <- list()
for (i in 1:length(countries)) {
  country <- countries[i]
  matchinds <- grep(country, SDwarnings$title)
  countrycount <- list(country, length(matchinds), unique(SDwarnings$title[matchinds]))
  SDwarnings_list[[i]] <- countrycount
}
SDwarnings_df <- as.data.frame(t(sapply(SDwarnings_list, "[", c(1,2))))
names(SDwarnings_df) <- c("Country", "nWarnings")
SDwarnings_df$Country <- as.character(SDwarnings_df$Country)
SDwarnings_df$nWarnings <- as.numeric(SDwarnings_df$nWarnings)

# Fix problems: Nigeria/Niger double counting, South Sudan/Sudan double counting
nWarnSouthSudan <- SDwarnings_df$nWarnings[SDwarnings_df$Country == "South Sudan"]
nWarnNigeria <- SDwarnings_df$nWarnings[SDwarnings_df$Country == "Nigeria"]
SDwarnings_df$nWarnings[SDwarnings_df$Country == "Sudan"] <- 
  SDwarnings_df$nWarnings[SDwarnings_df$Country == "Sudan"] - nWarnSouthSudan
SDwarnings_df$nWarnings[SDwarnings_df$Country == "Niger"] <- 
  SDwarnings_df$nWarnings[SDwarnings_df$Country == "Niger"] - nWarnNigeria

SDwarnings_df <- merge(SDwarnings_df, regionsonly, by.x = "Country", by.y = "name", all.x = T)
SDwarnings_df <- data.frame(SDwarnings_df$Country, SDwarnings_df$region, SDwarnings_df$nWarnings)

# Tabulate
SDwarnings_df <- SDwarnings_df[order(SDwarnings_df$SDwarnings_df.nWarnings, decreasing = T),]

# Save ranking by combined warnings
write.csv(SDwarnings_df, "WarningsRanking.csv")

## Ranking: top countries for American deaths abroad -----------------------------------------------

# Load data
library(rio)
library(plyr)
AmericanDeaths2 <- read.csv("https://query.data.world/s/c4k9pkipwpdth8286s8vklcyt",header=T, stringsAsFactors = F)

# Transform Cause.Of.Death to lower
AmericanDeaths2$cause.of.death <- tolower(AmericanDeaths2$cause.of.death)

# Select causes of death that are human-caused
desired <- c("homicide", "execution", "terrorist action", "hostage-related")
AmericanDeaths_desired <- AmericanDeaths2[AmericanDeaths2$cause.of.death %in% desired,] 

# Find number of deaths by country and order from greatest to least
AmericanDeaths_by_Country <- count(AmericanDeaths_desired, 'country')
AmericanDeaths_by_Country <- AmericanDeaths_by_Country[order(-AmericanDeaths_by_Country$freq),]

# Save rankings by country
write.csv(AmericanDeaths_by_Country, "DeathsRanking.csv")


# Ranking: Per-capita deaths -------------------------------------------------------------
# Load data
library(rio)
library(date)
regions <- import("https://query.data.world/s/2q7wm98dkyuoxxu6brmq3yqll",header=T)
regionsonly <- regions[, c("name", "region")]
countrycodes <- read.csv("https://query.data.world/s/do8eacem7jtjsclgr0ifzex20",header=T, stringsAsFactors = F)
AmericanDeaths <- read.csv("https://query.data.world/s/c4k9pkipwpdth8286s8vklcyt",header=T, stringsAsFactors = F)
BTS <- read.csv("https://query.data.world/s/4jn8nbk5yk1qyq9e9ow69uy9l",header=T, stringsAsFactors = F)

# Transform Cause.Of.Death to lower
AmericanDeaths$cause.of.death <- tolower(AmericanDeaths$cause.of.death)

# Select causes of death that are human-caused
desired <- c("homicide", "execution", "terrorist action", "hostage-related")
AmericanDeaths <- AmericanDeaths[AmericanDeaths$cause.of.death %in% desired,]

# Format dates
AmericanDeaths$datestr <- as.date(AmericanDeaths$date, order = "mdy")
BTS$MONTH[which(BTS$MONTH < 10)] <- paste0("0", BTS$MONTH[which(BTS$MONTH < 10)])
BTS <- BTS[!is.na(BTS$YEAR),]
BTS$mdy <- paste0(BTS$MONTH, sep = "-", "01", sep = "-", BTS$YEAR)
BTS$datestr <- as.date(BTS$mdy, order = "mdy")

# Aggregate travel data
BTS_aggregated <- aggregate(BTS$PASSENGERS, by = list(BTS$DEST_COUNTRY, BTS$datestr), FUN = "sum")
names(BTS_aggregated) <- c("Destination", "Date", "Passengers")

# Tabulate deaths & travelers per country for this time period
nmonths <- length(unique(BTS_aggregated$Date)) - 1
countries <- countrycodes$Description
validctrys <- vector()
ntravelers <- vector()
ndeaths <- vector()
j <- 1
for (i in 1:length(countries)) {
  ctry <- countries[i]
  ctrycode <- countrycodes$Code[countrycodes$Description == ctry]
  validctrys[j] <- ctry
  ntravelers[j] <- sum(BTS_aggregated$Passengers[BTS_aggregated$Destination == ctrycode])
  current_country_df <- AmericanDeaths$country[ which(AmericanDeaths$country == ctry)]
  ndeaths[j] <- length(current_country_df)
  j <- j+1
}
deathspercap <- data.frame(validctrys, ntravelers, ndeaths)
deathspercap <- deathspercap[ntravelers >= 100000,]
deathspercap$percap <- (deathspercap$ndeaths/deathspercap$ntravelers)*100000
deathspercap$percap <- round(deathspercap$percap, digits = 2)
deathspercap$ntravelers <- (round(deathspercap$ntravelers/100))*100
deathspercap <- merge(deathspercap, regionsonly, by.x = "validctrys", by.y = "name", all.x = T)
deathspercap <- deathspercap[order(deathspercap$percap, decreasing = T),]

# Save file
write.csv(deathspercap, "DeathsPerCapita.csv")

# Scatter plot: warnings by per-capita deaths --------------------------------------------

warndeathpcmerge <- merge(SDwarnings_df, deathspercap[,c("validctrys", "percap")],
                          by.x = "SDwarnings_df.Country", by.y = "validctrys", all.x = T)

plot(1, type = "n", xlab = "# of warnings", ylab = "# of deaths", 
     main = "Do Warnings Correlate w/ # of American Deaths\nper 100,000 Travelers?", xlim = c(0, 30),
     ylim = c(0, 5))
points(warndeathpcmerge$SDwarnings_df.nWarnings[warndeathpcmerge$SDwarnings_df.region == "Americas"], 
       warndeathpcmerge$percap[warndeathpcmerge$SDwarnings_df.region == "Americas"], pch = 16, 
       col = rgb(1, 0, 0, 0.5))
points(warndeathpcmerge$SDwarnings_df.nWarnings[warndeathpcmerge$SDwarnings_df.region == "Africa"], 
       warndeathpcmerge$percap[warndeathpcmerge$SDwarnings_df.region == "Africa"], pch = 16, 
       col = rgb(0, 1, 0, 0.5))
points(warndeathpcmerge$SDwarnings_df.nWarnings[warndeathpcmerge$SDwarnings_df.region == "Asia"], 
       warndeathpcmerge$percap[warndeathpcmerge$SDwarnings_df.region == "Asia"], pch = 16, 
       col = rgb(0, 0, 1, 0.5))
points(warndeathpcmerge$SDwarnings_df.nWarnings[warndeathpcmerge$SDwarnings_df.region == "Europe"], 
       warndeathpcmerge$percap[warndeathpcmerge$SDwarnings_df.region == "Europe"], pch = 16, 
       col = rgb(.82, .71, .55, 0.5))
points(warndeathpcmerge$SDwarnings_df.nWarnings[warndeathpcmerge$SDwarnings_df.region == "Oceania"], 
       warndeathpcmerge$percap[warndeathpcmerge$SDwarnings_df.region == "Oceania"], pch = 16, 
       col = rgb(.62, .47, .93, 0.5))

## Sub-rankings based on strength of correlation --------------------------------------

# Americans killed per capita
nowarnings_pc <- warndeathpcmerge[warndeathpcmerge$SDwarnings_df.nWarnings == 0 &
                                    warndeathpcmerge$percap > 0.5,]
nowarnings_pc <- nowarnings_pc[order(nowarnings_pc$percap, decreasing = T),]
nodeaths_pc <- warndeathpcmerge[warndeathpcmerge$SDwarnings_df.nWarnings > 5 &
                                  warndeathpcmerge$percap < 0.5,]
nodeaths_pc <- nodeaths_pc[order(nodeaths_pc$SDwarnings_df.nWarnings, decreasing = T),]
wellpredicted_pc <- warndeathpcmerge[warndeathpcmerge$SDwarnings_df.nWarnings > 5 &
                                       warndeathpcmerge$percap > 1,]
wellpredicted_pc <- wellpredicted_pc[order(wellpredicted_pc$SDwarnings_df.nWarnings, decreasing = T),]

nowarnings_pc <- nowarnings_pc[!is.na(nowarnings_pc$percap),]
nodeaths_pc <- nodeaths_pc[!is.na(nodeaths_pc$percap),]
wellpredicted_pc <- wellpredicted_pc[!is.na(wellpredicted_pc$percap),]

write.csv(nowarnings_pc, "deathbutnowarningPC.csv")
write.csv(nodeaths_pc, "warningbutnodeathPC.csv")
write.csv(wellpredicted_pc, "warningsanddeathsPC.csv")


## Do warnings impact travel behavior? ---------------------------------------------

# Load data
library(rio)
library(date)
regions <- import("https://query.data.world/s/2q7wm98dkyuoxxu6brmq3yqll",header=T)
regionsonly <- regions[, c("name", "region")]
countrycodes <- read.csv("https://query.data.world/s/do8eacem7jtjsclgr0ifzex20",header=T, stringsAsFactors = F)
# State Department Travel Warnings 2009-Jan. 2017 (833)
SDwarnings <- read.csv("https://query.data.world/s/c4k9pkipwpdth8286s8vklcyt",header=T, stringsAsFactors = F)
# BTS Monthly Travel Data 2010-2016
BTS <- read.csv("https://query.data.world/s/4jn8nbk5yk1qyq9e9ow69uy9l",header=T, stringsAsFactors = F)

# Weed out natural disasters
disasterwords <- c("hurricane", "tropical storm", "earthquake", "cyclone", "monsoon", "typhoon")
SDwarnings$description <- tolower(SDwarnings$description)
discards <- vector()
for (i in 1:length(disasterwords)) {
  matchinds <- grep(disasterwords[i], SDwarnings$description)
  discards <- c(discards, matchinds)
}
discards <- unique(discards)
SDwarnings <- SDwarnings[-discards,]

# Format dates
SDwarnings$datestr <- as.date(SDwarnings$pub_date, order = "mdy")
BTS$MONTH[which(BTS$MONTH < 10)] <- paste0("0", BTS$MONTH[which(BTS$MONTH < 10)])
BTS <- BTS[!is.na(BTS$YEAR),]
BTS$mdy <- paste0(BTS$MONTH, sep = "-", "01", sep = "-", BTS$YEAR)
# datestring is not working correctly
BTS$datestr <- as.date(BTS$mdy, order = "mdy")

# Aggregate travel data
BTS_aggregated <- aggregate(BTS$PASSENGERS, by = list(BTS$DEST_COUNTRY, BTS$mdy), FUN = "sum")
names(BTS_aggregated) <- c("Destination", "Date", "Passengers")

# Extract warning and travel data for each country
countries <- countrycodes$Description
#countries <- list("Mexico")
window_days <- 180
travel_list <- list()
for (i in 1:length(countries)) {
  country <- countries[i]
  countrycode <- countrycodes$Code[countrycodes$Description == country]
  if (country == "Sudan") {
    warninginds <- grep(country, SDwarnings$title)
    warninginds <- setdiff(warninginds, grep("South Sudan", SDwarnings$title))
    warningdates <- SDwarnings$pub_date[warninginds]
  }
  else if (country == "Niger") {
    warninginds <- grep(country, SDwarnings$title)
    warninginds <- setdiff(warninginds, grep("Nigeria", SDwarnings$title))
    warningdates <- SDwarnings$pub_date[warninginds]
  }
  else {
    # changed list of warning dates to date
    warningdates <- as.date(SDwarnings$pub_date[grep(country, SDwarnings$title)])
  }
  
  warningdates <- unique(warningdates)
  
  # Pull out travel data for country
  countrytravel <- BTS_aggregated[BTS_aggregated$Destination == countrycode,]
  
  # If there are valid warnings, calculate travel numbers around their dates.
  if (length(warningdates) > 0) {
    travelpre <- vector()
    travelpost <- vector()
    countrytravel$NewDate <- as.date(countrytravel$Date)
    for (k in 1:length(warningdates)) {
      # Split next line to first look at how many months match, filter to those with 6
      lower_limit = as.date(warningdates[k]) - window_days
      npremonths <- length(which(countrytravel$NewDate > lower_limit &
                                   countrytravel$NewDate < warningdates[k]))
      upper_limit = as.date(warningdates[k]) + window_days
      npostmonths <- length(which(countrytravel$NewDate > warningdates[k] &
                                    countrytravel$NewDate < upper_limit))
      
      if (npremonths == 6 & npostmonths == 6) {
        travelpre[k] <- sum(countrytravel$Passengers[countrytravel$NewDate > lower_limit &
                                                       countrytravel$NewDate < warningdates[k]], na.rm = T)
        
        travelpost[k] <- sum(countrytravel$Passengers[countrytravel$NewDate > warningdates[k] &
                                                        countrytravel$NewDate < upper_limit], na.rm = T)
      }
      else {travelpre[k] <- NA
      travelpost[k] <- NA
      }
    }
  }
  else {warningdates <- NA
  travelpre <- NA
  travelpost <- NA}
  
  travelbywarning <- data.frame(warningdates, travelpre, travelpost)
  travel_list[[i]] <- travelbywarning
}
names(travel_list) <- countries

# Extract travel change data from countries with adequate travel data
j <- 1
travelcountries <- vector()
travelpctchange <- vector()
for (i in 1:length(travel_list)){
  if (!is.na(travel_list[[i]][1,1])){
    country <- countries[i]
    traveldata <- travel_list[[i]]
    traveldata_valid <- traveldata[!is.na(traveldata$travelpre) & !is.na(traveldata$travelpost),]
    traveldata_nonzero <- traveldata_valid[traveldata_valid$travelpre != 0,]
    if (length(traveldata_nonzero$warningdates) >= 3) {
      traveldata_nonzero$pctchange <- ((traveldata_nonzero$travelpost - traveldata_nonzero$travelpre)/
                                         traveldata_nonzero$travelpre)*100
      travelcountries[j] <- country
      travelpctchange[j] <- mean(traveldata_nonzero$pctchange)
      j <- j + 1
    }
  }
}
travelchange <- data.frame(travelcountries, travelpctchange)
travelchange <- merge(travelchange, regionsonly, by.x = "travelcountries", by.y = "name", all.x = T)
travelchange <- travelchange[order(travelchange$travelpctchange),]

write.csv(travelchange, "TravelAfterWarning.csv")
